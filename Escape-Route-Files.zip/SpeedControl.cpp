#include "SpeedControl.h"
#include "SpawnCars.h"
#include "SignalControl.h"

const double pi = 3.14159265358979323846;
vector<Vector2f> rt = { {135, 45}, {45, 315}, {315, 225}, {225, 135} };

bool ObeySignals(Car& car)
{
    Vector2f car_pos = car.body.getPosition();

    Vector2f front = {
        car_pos.x + 96 * cosf(car.body.getRotation() * pi / 180.f),
        car_pos.y + 96 * sinf(car.body.getRotation() * pi / 180.f)
    };

    const float stopping_distance = 350.f; // How many units before the line to start stopping
    const float lane_width_tolerance = 480.f; // How far from the center of the lane is acceptable

    for (size_t k = 0; k < Signal::points.size(); k++) {
        for (int i = 0; i < 4; i++) {
            Vector2f stop_line_pos = Vector2f((Signal::points[k] + Vector2f(Signal::dir[i].x * 15.f, Signal::dir[i].y * 15.f)).x * 29335.f / 1920.f, (Signal::points[k] + Vector2f(Signal::dir[i].x * 15.f, Signal::dir[i].y * 15.f)).y * 16504.f / 1080.f);
            Vector2f min_dis = stop_line_pos - front;
            if (min_dis.x * min_dis.x + min_dis.y * min_dis.y > 600.f * 600.f) continue;
            // Check if the car is aligned with the direction of a red light
            if (((int)car.body.getRotation() % 360) < rt[i].x && car.body.getRotation() > rt[i].y && Signal::stop[k][i]) {
              
                float distance_to_stop_line = 0.f;
                float offset_from_lane_center = 0.f;

                switch (i) {
                case 2: // Northbound
                    distance_to_stop_line = front.y - stop_line_pos.y;
                    offset_from_lane_center = fabs(front.x - stop_line_pos.x);
                    if (distance_to_stop_line > 0.f && distance_to_stop_line < stopping_distance && offset_from_lane_center < lane_width_tolerance) return true;
                    break;
                case 3: // Westbound
                    distance_to_stop_line = front.x - stop_line_pos.x;
                    offset_from_lane_center = fabs(front.y - stop_line_pos.y);
                    if (distance_to_stop_line > 0.f && distance_to_stop_line < stopping_distance && offset_from_lane_center < lane_width_tolerance) return true;
                    break;
                case 0:  // Southbound
                    distance_to_stop_line = stop_line_pos.y - front.y;
                    offset_from_lane_center = fabs(front.x - stop_line_pos.x);
                    if (distance_to_stop_line > 0.f && distance_to_stop_line < stopping_distance && offset_from_lane_center < lane_width_tolerance) return true;
                    break;
                case 1:   // Eastbound
                    distance_to_stop_line = stop_line_pos.x - front.x;
                    offset_from_lane_center = fabs(front.y - stop_line_pos.y);
                    if (distance_to_stop_line > 0.f && distance_to_stop_line < stopping_distance && offset_from_lane_center < lane_width_tolerance) return true;
                    break;
                }
            }
        }
    }

    return false; 
}

void checkCollision(Car& car, Sprite& plr, double& spd, bool& col, Vector2f& plv)
{
    Vector2f impactVector = (plr.getPosition() - car.body.getPosition());

    float distance = sqrt((impactVector.x * impactVector.x) + (impactVector.y * impactVector.y));
    if (distance == 0.0f) {
        car.col_v = { 0,0 }; // Set a safe, zero velocity
        car.rt = 0;
        return;
    }
    Vector2f n = impactVector / distance;

    Vector2f plr_v = { (float)spd * cosf(plr.getRotation() * pi / 180.f), (float)spd * sinf(plr.getRotation() * pi / 180.f) };

    float car_ang_rad = car.body.getRotation() * pi / 180.f;
    Vector2f car_v = { (float)car.speed * cosf(car_ang_rad), (float)car.speed * sinf(car_ang_rad) };

    float vn = dot((plr_v - car_v), impactVector);

    Vector2f impulse =  (n * vn) / 7.f;
    car_v += impulse;
    plr_v -= impulse;

    car.col_v = car_v;
    plv = plr_v;
    col = true;

    if (plr.getRotation() - car.body.getRotation() == 0.f || abs(plr.getRotation() - car.body.getRotation()) == 180.f) {
        car.rt = 0.f;
    }
    else {
        car.rt = fabs(car.speed - spd);
    }
}

void speedctrl(Car& car, const vector<Car*>& nearbyCars, double& RENDER_WORLD_SCALE_X, double& RENDER_WORLD_SCALE_Y) {
    float left = car.body.getPosition().x + car.body.getGlobalBounds().width * cosf(car.body.getRotation() * pi / 180.f);
    float top = car.body.getPosition().y + car.body.getGlobalBounds().width * sinf(car.body.getRotation() * pi / 180.f);
    Sprite colArea;
    const Texture* area;
    area = car.body.getTexture();
    colArea.setTexture(*area);
    colArea.setPosition(left, top);
    colArea.setScale(96.f / area->getSize().x, 53.32 / area->getSize().y);
    colArea.setRotation(car.body.getRotation());
    bool collision_imminent = false;

    for (Car* otherCar : nearbyCars) {
        if (otherCar->id == car.id) continue;
        if (colArea.getGlobalBounds().intersects(otherCar->body.getGlobalBounds()) && car.enteredCorrectly == otherCar->enteredCorrectly) {
            if (otherCar->speed < car.speed || otherCar->body.getRotation() != car.body.getRotation()) {
                collision_imminent = true;
                break; // A collision is likely, no need to check other cars
            }
        }
    }

    bool is_signal_red = ObeySignals(car);

    if (is_signal_red || collision_imminent) {
        car.speed = max(0.0, car.speed - 0.015);
        if (car.speed < 0.1) car.speed = 0;
    }
    else {
        if (car.speed < 3.0 && !car.collided) {
            car.speed = min(3.0, car.speed + 0.002);
        }
    }
}