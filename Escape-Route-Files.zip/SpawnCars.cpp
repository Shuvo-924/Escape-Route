#include<SFML/OpenGL.hpp>
#include "SpawnCars.h"
#include "SpeedControl.h"

static unsigned int getNextCarId() {
	static unsigned int nextId = 0;
	return nextId++;
}

void Cars::initVar()
{
	srand(time(NULL));
	vector<String> loc = { {"Car(G).png"}, {"Car(P).png"}, {"Car(R).png"} };
	for (int i = 0;i < 3;i++) {
		Texture x;
		x.loadFromFile(loc[i]);
		skins.push_back(x);
	}
	ifstream deploy("RandNodes.txt");
	float x, y;
	double z;
	while (deploy >> x >> y >> z) {
		points.push_back({ {x,y},(float)z });
	}
	size = { 96, 53.32 };
	int n = 15;
	engineRunningBuffer.loadFromFile("Car_Running.ogg");
	brakeBuffer.loadFromFile("Car_Brake.ogg");
	hornBuffer.loadFromFile("Car_Horn.ogg");
	while (n--) AddCars();
	SpawnDelay.restart();
	plr_id = getNextCarId();
	ifstream curveStartsFile("ChangeDir.txt");
	while (curveStartsFile >> x >> y) {
		curveStartPoints.insert({ x, y });
	}
	curveStartsFile.close();
	ifstream allCurvesFile("Curves.txt");
	while (allCurvesFile >> x >> y) {
		allCurvePoints.insert({ x, y });
	}
	allCurvesFile.close();
	ifstream bridgepoints("OverBridgeArea.txt"); while (bridgepoints >> x >> y) { BridgePoints.insert({ x, y }); } bridgepoints.close();
	ifstream bridgeCorners("ShapeStart.txt");
	while (bridgeCorners >> x >> y) {
		Vector2f start = { x, y };
		vector<Vector2f> currShape;
		currShape.push_back(start);
		unordered_set<Vector2f, Vector2fHash> vis;
		vector<Vector2f> dir = { {1,0},{0,1},{-1,0},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
		Vector2f curr = start;
		Vector2f next = curr + dir[0];
		vis.insert(start);
		while (next != start) {
			bool foundNextPoint = false;
			for (int i = 0;i < 8;i++) {
				next = curr + dir[i];
				if (BridgePoints.count(next) && !vis.count(next)) {
					vis.insert(next);
					currShape.push_back(next);
					curr = curr + dir[i];
					foundNextPoint = true; // We found the next point, break the inner loop
					break;
				}
			}
			if (!foundNextPoint) break;
		}
		bridgeArea.push_back(currShape);
	}
	bridgeCorners.close();
	ifstream enter("EntryPoints.txt"); while (enter >> x >> y) { Gates.push_back({ x, y }); } enter.close();
	for (vector<Vector2f>& points : bridgeArea) {
		ConvexShape sp;
		unordered_set<Vector2f, Vector2fHash> entry;
		unordered_set<Vector2f, Vector2fHash> borders;
		sp.setPointCount(points.size());
		for (size_t i = 0; i < points.size(); ++i) {
			Vector2f worldPoint = Vector2f(points[i].x * 29335.f / 1920.f, points[i].y * 16504.f / 1080.f);
			sp.setPoint(i, worldPoint);
			borders.insert(worldPoint);
			for (int j = 0;j < Gates.size();j++) {
				Vector2f dis = points[i] - Gates[j];
				if (dis.x * dis.x + dis.y * dis.y < 5) entry.insert({ Gates[j].x * 29335.f / 1920.f, Gates[j].y * 16504.f / 1080.f });
			}
		}
		bridges.push_back({ sp, borders, entry });
	}
}

vector<Vector2f> Cars::findOrderedCurvePath(const Vector2f& startNode)
{
	vector<Vector2f> orderedPath;
	if (allCurvePoints.find(startNode) == allCurvePoints.end()) {
		return orderedPath;
	}
	orderedPath.push_back(startNode);
	unordered_set<Vector2f, Vector2fHash> visitedInThisSearch;
	queue<Vector2f> search;
	search.push(startNode);
	while (!search.empty()) {
		Vector2f parent = search.front();
		visitedInThisSearch.insert(parent);
		vector<Vector2f> dir = { {1,0},{0,1},{-1,0},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
		for (int i = 0;i < 8;i++) {
			Vector2f neighbor = parent + dir[i];
			if (visitedInThisSearch.count(neighbor)) continue;
			if (allCurvePoints.count(neighbor)) {
				orderedPath.push_back(neighbor);
				search.push(neighbor);
			}
		}
		search.pop();
	}

	return orderedPath;
}

void Cars::AddCars()
{
	int n = rand() % 3;
	while (n--) {
		Texture& tex = skins[rand() % 3];
		Car newCar;
		newCar.id = getNextCarId();
		newCar.body.setTexture(tex);

		newCar.body.setScale(size.x / tex.getSize().x, size.y / tex.getSize().y);
		double spd = 3.f;
		newCar.speed = spd;
		newCar.lastspeed = spd;

		pair<Vector2f, float> strt = points[rand() % 21];

		const double pi = 3.14159265358979323846;
		newCar.body.setPosition(Vector2f(strt.first.x * scaleX, strt.first.y * scaleY) - Vector2f(newCar.body.getGlobalBounds().width * cosf(strt.second * pi / 180.f), newCar.body.getGlobalBounds().width * sinf(strt.second * pi / 180.f)));
		newCar.body.setRotation(strt.second);
		FloatRect bounds = newCar.body.getGlobalBounds();
		float width = bounds.width;
		newCar.body.setOrigin(bounds.width / 2.f, bounds.height / 2.f);
		newCar.velocity = { spd * cosf(strt.second * pi / 180.f), spd * sinf(strt.second * pi / 180.f) };

		int f = bodies.size();
		while (f--) {
			bool found = false;
			for (int i = 0;i < bodies.size();i++) {
				if (bounds.intersects(bodies[i].body.getGlobalBounds())) {
					newCar.body.move(-(width + 10.f) * cosf(strt.second * pi / 180.f), -(width + 10.f) * sinf(strt.second * pi / 180.f));
					found = true;
				}
			}
			if (!found) break;
		}

		newCar.engineSound.setBuffer(engineRunningBuffer);
		newCar.engineSound.setLoop(true);
		newCar.engineSound.setVolume(25.f);

		newCar.hornSound.setBuffer(hornBuffer);
		newCar.hornSound.setLoop(true);
		newCar.hornSound.setVolume(80.f);

		newCar.brakeSound.setBuffer(brakeBuffer);
		newCar.brakeSound.setVolume(40.f);
		newCar.honk.restart();

		bodies.push_back(move(newCar));
	}
}

Cars::Cars(float worldWidth, float worldHeight) : grid(worldWidth, worldHeight, 8, 8)
{
	initVar();
}

void Cars::Spawn()
{
	for (auto& cars : bodies) {
		moving.push_back(move(cars));
	}
	bodies.clear();
}

void Cars::maskcars(RenderWindow& window, Car& car) {
	bool isOnBridge = false;

	const Transform& carTransform = car.body.getTransform();
	FloatRect carBounds = car.body.getLocalBounds(); // Use local bounds before transformation

	// Define the points on the car we want to check (in its own local space)
	vector<Vector2f> checkPoints;
	checkPoints.push_back({ carBounds.width, carBounds.height / 2.f }); // Middle of the front bumper
	checkPoints.push_back({ 0.f, carBounds.height / 2.f });             // Middle of the rear bumper
	checkPoints.push_back({ carBounds.width / 2.f, 0.f });              // Top-middle of the roof
	checkPoints.push_back({ carBounds.width / 2.f, carBounds.height }); // Bottom-middle of the chassis

	// Convert these local points to their current world positions
	vector<Vector2f> worldCheckPoints;
	for (const auto& p : checkPoints) {
		worldCheckPoints.push_back(carTransform.transformPoint(p));
	}

	for (const auto& curr : bridges)
	{
		bool isAnyPointInside = false;
		// Check if ANY of our car's points are inside the bridge area.
		for (const auto& point : worldCheckPoints) {
			if (isPointInsideConvexShape(point, curr.area)) {
				isAnyPointInside = true;
				isOnBridge = true;
				currentBridge = &curr;
				break; // Found one point inside, no need to check others
			}
		}

		if (isAnyPointInside)
		{
			for (const auto& entryPoint : curr.entryPoints)
			{
				if (car.body.getGlobalBounds().contains(entryPoint)) {
					car.enteredCorrectly = true;
					break;
				}
			}
			if (car.enteredCorrectly) break;
		}
	}
	if (!isOnBridge) car.enteredCorrectly = false;
	// RENDER DECISION PER-CAR
	if (car.enteredCorrectly || !isOnBridge)
	{
		// CASE A: Car is not on a bridge OR it entered correctly.
		// It should appear OVER the bridge. Just draw it normally.
		window.draw(car.body);
	}
	else
	{
		glEnable(GL_STENCIL_TEST);
		glClear(GL_STENCIL_BUFFER_BIT);
		glStencilFunc(GL_ALWAYS, 1, 0xFF);
		glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
		glStencilMask(0xFF);
		glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE); // Don't draw the shape to the screen
		window.draw(currentBridge->area);
		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE); // Re-enable color drawing
		glStencilFunc(GL_NOTEQUAL, 1, 0xFF);
		glStencilMask(0x00); // Don't write to the stencil buffer anymore
		window.draw(car.body);
		glDisable(GL_STENCIL_TEST);
	}
}

void Cars::drawCars(RenderWindow& window, double RENDER_WORLD_SCALE_X, double RENDER_WORLD_SCALE_Y, Sprite& plr, double& spd, bool& col, Vector2f& plv) {
	grid.clear();
	for (auto it = moving.begin();it != moving.end();it++) {
		grid.add(&(*it));
	}
	Car pl;
	pl.body = plr;
	pl.speed = spd;
	pl.id = getNextCarId();
	pl.engineSound.setBuffer(engineRunningBuffer);
	pl.brakeSound.setBuffer(brakeBuffer);
	pl.hornSound.setBuffer(hornBuffer);
	pl.honk.restart();
	grid.add(&pl);

	const double pi = 3.14159265358979323846;
	const float MAX_SOUND_DISTANCE = 2000.f;
	const float MAX_SOUND_DISTANCE_SQUARED = MAX_SOUND_DISTANCE * MAX_SOUND_DISTANCE;
	View view = window.getView();
	FloatRect viewBounds(view.getCenter() - view.getSize() / 2.f, view.getSize());

	for (auto it = moving.begin(); it != moving.end();) {
		Car& car = *it;
		bool shouldIncrement = true;
		if ((car.body.getPosition().x > 29335.f || car.body.getPosition().x < 0.f || car.body.getPosition().y > 16504.f || car.body.getPosition().y < 0.f) && car.out == true) {
			car.out = false;
			shouldIncrement = false;
			it = moving.erase(it);
			continue;
		}
		if ((car.body.getPosition().x < 29335.f && car.body.getPosition().x > 0.f) && (car.body.getPosition().y < 16504.f && car.body.getPosition().y > 0.f)) {
			car.out = true;
		}

		if (car.isFollowingCurve) {
			if (car.curvePathIndex >= car.currentCurvePath.size()) {
				car.isFollowingCurve = false;
			}
			else {
				Vector2f targetPoint = car.currentCurvePath[car.curvePathIndex];

				targetPoint.x *= RENDER_WORLD_SCALE_X;
				targetPoint.y *= RENDER_WORLD_SCALE_Y;

				Vector2f direction = targetPoint - car.body.getPosition();
				float targetAngle = atan2(direction.y, direction.x) * 180.f / pi;

				float currentAngle = car.body.getRotation();
				float angleDiff = targetAngle - currentAngle;
				if(sqrt(direction.y * direction.y + direction.x * direction.x) < 8.f)
				car.curvePathIndex+=2;

				if (angleDiff > 180)  angleDiff -= 360;
				if (angleDiff < -180) angleDiff += 360;
				car.body.rotate(angleDiff * 1.f);
			}
		}
		else {
			Vector2f carPos = car.body.getPosition();
			Vector2f carPosMapCoords = { carPos.x / (float)RENDER_WORLD_SCALE_X, carPos.y / (float)RENDER_WORLD_SCALE_Y };

			for (const auto& startPoint : curveStartPoints) {
				float dx = startPoint.x - carPosMapCoords.x;
				float dy = startPoint.y - carPosMapCoords.y;
				if (dx * dx + dy * dy < (5.f * 5.f)) {

					vector<Vector2f> path = findOrderedCurvePath(startPoint);
					if (path.size() > 1) {
						car.isFollowingCurve = true;
						car.currentCurvePath = path;
						car.curvePathIndex = 0;
						break;
					}
				}
			}
		}
		vector<Car*> nearbyCars = grid.getNearbyCars(&car);
		if (viewBounds.intersects(car.body.getGlobalBounds())) {

			if (car.speed <= car.lastspeed - 0.01 && car.speed > 0.f) {
				Vector2f dis = plr.getPosition() - car.body.getPosition();
				float distSq = dis.x * dis.x + dis.y * dis.y;
				float volumeRatio = 1.0f - (distSq / MAX_SOUND_DISTANCE_SQUARED);
				if (volumeRatio < 0) volumeRatio = 0; // Clamp volume at 0
				car.brakeSound.setVolume(100.f * volumeRatio);

				if (car.brakeSound.getStatus() != Sound::Playing) {		
					car.brakeSound.play(); // Use car.brakeSound
				}
			}
			else if (car.brakeSound.getStatus() == Sound::Playing) {
				car.brakeSound.stop(); // Use car.brakeSound
			}

			if (car.speed > 0.f) {
				Vector2f dis = plr.getPosition() - car.body.getPosition();
				float distSq = dis.x * dis.x + dis.y * dis.y;
				float volumeRatio = 1.0f - (distSq / MAX_SOUND_DISTANCE_SQUARED);
				if (volumeRatio < 0) volumeRatio = 0;
				car.engineSound.setVolume(100.f * volumeRatio);
				if (car.engineSound.getStatus() != Sound::Playing) {
					car.engineSound.play(); // Use car.engineSound
				}
				float max_ai_speed = 1.5f;
				float pitch = 1.0f + (car.speed / max_ai_speed);
				car.engineSound.setPitch(pitch); // Use car.engineSound
			}
			else {
				if (car.engineSound.getStatus() == Sound::Playing) {
					car.engineSound.stop(); // Use car.engineSound
				}
			}

			if (car.speed == 0 && !car.still) {
				car.still = true;
				car.honk.restart();
			}

			else if (car.speed > 0) {
				car.still = false;
			}

			if (car.honk.getElapsedTime().asSeconds() >= 60 && car.still) {
				if (car.hornSound.getStatus() != Sound::Playing) {
					car.hornSound.play();
				}
			}
			else if (car.hornSound.getStatus() == Sound::Playing) {
				car.hornSound.stop();
			}
		}
		else {
			if (car.engineSound.getStatus() == Sound::Playing) {
				car.engineSound.stop(); // Use car.engineSound
			}
			if (car.hornSound.getStatus() == Sound::Playing) {
				car.hornSound.stop();
			}
		}
		if (!car.collided && car.body.getGlobalBounds().intersects(plr.getGlobalBounds())) {
			car.collided = true;
			checkCollision(car, plr, spd, col,plv);
		}

		car.lastspeed = car.speed;
		car.prevPos = car.body.getPosition();
		speedctrl(car, nearbyCars, RENDER_WORLD_SCALE_X, RENDER_WORLD_SCALE_Y);
		
		CollisionInfo Collision = railling.checkBorders(car.body, car.velocity);

		if (Collision.collided && !car.crashState) {
			car.crashState = true;

			Vector2f carDir = normalize(car.velocity);

			// Calculate the angle between the car's direction and the wall's normal
			float impactDot = dot(carDir, Collision.railingNormal);
			// acos gives the angle in radians. Convert to degrees.
			float impactAngle = acos(abs(impactDot)) * 180.f / pi;

			// --- CRITICAL ANGLE LOGIC ---
			if (impactAngle < 45.f) { // Angle is relative to the normal, so < 45 is a "head-on" collision
				car.velocity = -2.f * (impactAngle / 90.f) * car.velocity; // Dead stop
				car.speed = (-(float)car.speed * 0.98);
				// Apply a small "rebound" rotation away from the wall
				float cross = carDir.x * Collision.railingNormal.y - carDir.y * Collision.railingNormal.x;
				car.rt = (cross > 0 ? -(impactAngle) : impactAngle); // Rotate away
			}
			// --- GLANCING BLOW LOGIC ---
			else {
				// Reflect velocity along the wall
				car.velocity = car.velocity - dot(car.velocity, Collision.railingNormal) * Collision.railingNormal;

				// Calculate the rotation needed to align with the wall
				float wallAngle = atan2(Collision.wallDirection.y, Collision.wallDirection.x) * 180.f / pi;
				float carAngle = car.body.getRotation();
				float angleDiff = wallAngle - carAngle;
				while (angleDiff > 180) angleDiff -= 360;
				while (angleDiff < -180) angleDiff += 360;

				// Apply a fraction of the difference as spin to smoothly align
				car.rt = angleDiff * 0.02f;
			}

			// Correct position to prevent sinking
			car.body.setPosition(car.prevPos);
		}

		// --- STEP 5: POST-COLLISION PHYSICS (FRICTION) ---
		if (car.crashState) {
			car.velocity *= 0.85f;
			car.rt *= 0.9f; // Make spin decay a bit faster

			if (sqrt(dot(car.velocity, car.velocity)) < 0.5f && fabs(car.rt) < 0.5f) {
				car.crashState = false;
				car.rt = 0.f;
				car.speed = 0.f;
			}
		}
		else if (car.collided) {
			// Apply the rotation
			car.body.move(car.col_v);
			car.body.rotate(car.rt);

			// Apply friction to the spin
			car.col_v.x *= 0.9;
			car.col_v.y *= 0.9;
			car.rt *= 0.95f; // Reduce spin by 5% each frame

			// Exit the collision state if the spin is negligible
			if (car.col_v.x * car.col_v.x + car.col_v.y * car.col_v.y < 0.2f) {
				car.rt = 0.f;
				car.col_v = { 0,0 };
			}
		}
		else {
			float ang = car.body.getRotation();
			float dx = car.speed * cosf(ang * pi / 180.f);
			float dy = car.speed * sinf(ang * pi / 180.f);
			car.velocity = { dx,dy };
			car.body.move(dx, dy);
		}

		if (viewBounds.intersects(car.body.getGlobalBounds())) {
			maskcars(window, car);
		}
		if (shouldIncrement) it++;
	}
}

vector<Bridge> Cars::getBridges()
{
	return bridges;
}

list<Car>& Cars::getMovingCars()
{
	return moving;
}
