#include<iostream>
#include"Game.h"

using namespace sf;

int main() {
    Game game;
    srand(time(NULL));
    while (game.getWinOpen()) {
        game.update();
        game.render();
    }
    return 0;
}