#ifndef BORDERGRID_H
#define BORDERGRID_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <unordered_map>
#include "CustomFunctions.h" // For the Vector2fHash

// Forward declare the custom hash for pairs since it's used inside the class
namespace std {
    template<>
    struct hash<pair<int, int>> {
        size_t operator()(const pair<int, int>& p) const {
            // A simple hash combination for a pair of integers
            return hash<int>()(p.first) ^ (hash<int>()(p.second) << 1);
        }
    };
}

class BorderGrid {
private:
    // The main data structure. It maps a grid cell coordinate (e.g., cell [5, 12])
    // to a vector of all the border points that exist inside that cell.
    unordered_map<pair<int, int>, vector<Vector2f>> grid;

    // The size of each individual cell in world coordinates.
    // A larger cell size is faster for setup but less precise for lookups.
    // A smaller cell size is slower to build but faster for lookups.
    int cellSizeX;
    int cellSizeY;

public:
    // Constructor
    BorderGrid() : cellSizeX(256), cellSizeY(256) {} // Default constructor

    BorderGrid(float worldWidth, float worldHeight, int cellsX, int cellsY) {
        // Calculate the size of each cell based on the world dimensions and desired number of cells
        cellSizeX = static_cast<int>(worldWidth / cellsX);
        cellSizeY = static_cast<int>(worldHeight / cellsY);
    }

    // Calculates which grid cell a world-space point belongs to.
    pair<int, int> getCellCoords(const sf::Vector2f& worldPosition) const {
        int cellX = static_cast<int>(worldPosition.x / cellSizeX);
        int cellY = static_cast<int>(worldPosition.y / cellSizeY);
        return { cellX, cellY };
    }

    // Adds a border point to the correct cell in the grid.
    void addPoint(const Vector2f& point) {
        grid[getCellCoords(Vector2f(point.x * 29335.f / 1920.f, point.y * 16504.f / 1080.f))].push_back(point);
    }

    // This is the main query function.
    // It returns all points in the cell containing 'worldPosition' AND all 8 neighboring cells.
    vector<sf::Vector2f> getNearbyPoints(const Vector2f& worldPosition) {
        vector<sf::Vector2f> nearbyPoints;
        pair<int, int> centerCell = getCellCoords(worldPosition);

        // Loop through a 3x3 area of cells centered on the car's current cell
        for (int y = -1; y <= 1; ++y) {
            for (int x = -1; x <= 1; ++x) {
                pair<int, int> cellToFind = { centerCell.first + x, centerCell.second + y };

                // Use 'find' to check if the cell actually has any points in it
                auto it = grid.find(cellToFind);
                if (it != grid.end()) {
                    // If it does, add all the points from that cell's vector to our results
                    nearbyPoints.insert(nearbyPoints.end(), it->second.begin(), it->second.end());
                }
            }
        }

        return nearbyPoints;
    }
};

#endif // BORDERGRID_H