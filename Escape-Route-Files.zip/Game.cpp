#include<SFML/OpenGL.hpp>
#include "Game.h"
#include "SignalControl.h"

void Game::initMinimal()
{
	window = nullptr;
	map = nullptr;
	desktopMode = VideoMode::getDesktopMode();
	ContextSettings settings;
	settings.depthBits = 24;      // Request a 24-bit depth buffer
	settings.stencilBits = 8;     // Request an 8-bit stencil buffer
	settings.antialiasingLevel = 4; // Optional, but nice to have

	window = new RenderWindow(this->desktopMode, "Escape Route", Style::Close | Style::Titlebar, settings);
	window->setPosition(Vector2i(-15, 0));
	icon.loadFromFile("Icon.png");
	window->setIcon(icon.getSize().x, icon.getSize().y, icon.getPixelsPtr());
	disp.loadFromFile("Gravity.ttf");
	vector<string> c = { {"CPP.png"}, {"SFML.png"} };
	creditesImg.reserve(c.size());
	for (int i = 0;i < 2;i++) {
		Texture t;
		t.loadFromFile(c[i]);
		creditesImg.push_back(t);
		Sprite x;
		x.setTexture(creditesImg.back());
		x.setPosition(window->getSize().x / 2.f - x.getLocalBounds().width / 2.f, window->getSize().y / 2.f - x.getLocalBounds().height / 2.f);
		credits.push_back(x);
	}
	fadeClock.restart();
	RENDER_WORLD_SCALE_X = 29335.f / 1920.f;
	RENDER_WORLD_SCALE_Y = 16504.f / 1080.f;
}

void Game::bfs() {
	unordered_set<Vector2f, Vector2fHash> vis;
	queue<Vector2f> p;
	p.push(endpoints[0]);
	while (!p.empty()) {
		Vector2f curr = p.front();
		vis.insert(curr);

		for (auto& [a, b] : roadGraph[curr]) {
			if (!vis.count({ a,b })) {
				p.push({ a,b });
				circles.push_back({ a, b });
			}
		}
		p.pop();
	}
}

void Game::loadAssetsAndData()
{
	loadingEllipsisText.setFont(disp);
	loadingEllipsisText.setCharacterSize(40);
	loadingEllipsisText.setFillColor(Color::White);
	loadingEllipsisText.setPosition(50.f, desktopMode.height - 100.f);
	ellipsisCount = 0;

	int numFrames = 240;
	vector<Texture> localFrames; // Create a temporary, local vector
	localFrames.resize(numFrames);
	for (int i = 0; i < numFrames; ++i) {
		stringstream ss;
		ss << "Frames/frame_" << setw(4) << setfill('0') << (i + 1) << ".png";
		if (!localFrames[i].loadFromFile(ss.str())) {
			cout << "Error loading frame: " << ss.str() << endl;
		}
	}

	{
		lock_guard<mutex> lock(loadingMutex);
		loadingFrames = move(localFrames); // Efficiently move the data

		if (!loadingFrames.empty() && loadingFrames[0].getSize().x > 0) {
			currentFrameIndex = 0;
			loadingSprite.setTexture(loadingFrames[currentFrameIndex]);
			float scaleX = (float)desktopMode.width / loadingSprite.getLocalBounds().width;
			float scaleY = (float)desktopMode.height / loadingSprite.getLocalBounds().height;
			float finalScale = min(scaleX, scaleY);
			loadingSprite.setScale(finalScale, finalScale);
			loadingSprite.setOrigin(loadingSprite.getLocalBounds().width / 2.f, loadingSprite.getLocalBounds().height / 2.f);
			loadingSprite.setPosition(desktopMode.width / 2.f, desktopMode.height / 2.f);
		}
	}
	loadRoadGraph("RoadGraphNew.cache");
	
	map = new TileMap("map_tiles", TILE_SIZE, MAP_WIDTH_TILES, MAP_HEIGHT_TILES);
	start = -1; end = -1; isAnimatingPath = false; pathAnimationIndex = 0; speed = 0.f;

	playerEngineBuffer.loadFromFile("Car_Runningnew.ogg");
	playerBrakeBuffer.loadFromFile("Car_Brake.ogg");
	policeSiren.loadFromFile("Police_Siren.ogg");
	// Configure the player's engine sound
	playerEngineSound.setBuffer(playerEngineBuffer);
	siren.setBuffer(policeSiren);
	siren.setVolume(100.f);
	siren.setLoop(true);
	playerEngineSound.setLoop(true); // The engine sound should loop continuously
	playerEngineSound.setVolume(100.f); // Adjust volume as needed

	// Configure the player's brake sound
	playerBrakeSound.setBuffer(playerBrakeBuffer);
	playerBrakeSound.setVolume(100.f);

	bg.loadFromFile("Routes_Map1.png");
	playerCar.loadFromFile("Car(P).png");
	policeCar.loadFromFile("Police.png");
	ar.loadFromFile("Arrow.png");
	fadeImg.create(1920, 1080);

	cityimg.loadFromFile("City1.png");
	city.setTexture(cityimg); city.setScale(1920.f / city.getLocalBounds().getSize().x, 1080.f / city.getLocalBounds().getSize().y);
	rd.setTexture(bg); rd.setScale(1920.0f / 16384.0f, 1080.0f / 9218.0f);
	minimap.minimapBackgroundTexture.loadFromFile("mini.png");
	minimap.minimapBackgroundSprite.setTexture(minimap.minimapBackgroundTexture);
	cancel.loadFromFile("Cancel.png");
	cancelbtn.setTexture(cancel);
	cancelbtn.setScale(0.05, 0.05);
	cancelbtn.setPosition(1920.f - cancelbtn.getGlobalBounds().width * 1.5f, cancelbtn.getGlobalBounds().height / 2.f);
	plr.setTexture(playerCar); plr.setScale(0.04, 0.04);
	plc.setTexture(policeCar); plc.setScale(96.f / policeCar.getSize().x, 53.32 / policeCar.getSize().y);
	dispPLC.setTexture(policeCar); dispPLC.setScale(96.f / policeCar.getSize().x, 96.f / policeCar.getSize().x);
	FloatRect bounds = plr.getLocalBounds();
	plr.setOrigin(bounds.width / 2.f, bounds.height / 2.f);
	plc.setOrigin(plc.getLocalBounds().width / 2.f, plc.getLocalBounds().height / 2.f);
	dispPLC.setOrigin(plc.getLocalBounds().width / 2.f, plc.getLocalBounds().height / 2.f);
	RandomCars->Spawn();
	spawnDelay.restart();
	timer.restart();

	ElapsedTime.setFont(disp);
	ElapsedTime.setCharacterSize(40);
	ElapsedTime.setFillColor(Color::White);
	ElapsedTime.setOutlineColor(Color::Black);
	ElapsedTime.setOutlineThickness(2.f);
	ElapsedTime.setPosition(70, 50);
	d4.resize(4);
	select.setFont(disp), ans.setFont(disp);
	select.setString("Choose an Intersection point to Intercept the Signals -> ");
	select.setPosition(window->getSize().x / 2.f - 30 * (select.getLetterSpacing() + select.getString().getSize()) / 2, 100);
	select.setOutlineColor(Color::Black);
	select.setOutlineThickness(1.f);
	select.setCharacterSize(40);
	ans.setString(signalPoint);
	ans.setPosition(window->getSize().x / 2.f + 20.5 * (select.getLetterSpacing() + select.getString().getSize()) / 2, 100);
	ans.setOutlineColor(Color::Black);
	ans.setOutlineThickness(1.f);
	ans.setCharacterSize(40);

	float x, y;
	shapes = RandomCars->getBridges();

	ifstream startFile("Nodes.txt"); while (startFile >> x >> y) { endpoints.push_back({ x, y }); } startFile.close();
	ifstream lm("SearchArea.txt"); while (lm >> x >> y) { searchlimit.insert({ x, y }); } lm.close();
	
	fadeShape.setSize(Vector2f(static_cast<float>(desktopMode.width), static_cast<float>(desktopMode.height)));
	fadeShape.setFillColor(Color(0, 0, 0, 0));

	{
		lock_guard<mutex> lock(loadingMutex);
		isLoadingFinished = true;
	}
}

void Game::updateAndDrawLoadingAnimation()
{
	if (ellipsisClock.getElapsedTime() > timePerEllipsis) {
		ellipsisCount = (ellipsisCount + 1) % 4;
		string base = "Loading";
		for (int i = 0; i < ellipsisCount; ++i) {
			base += ".";
		}
		loadingEllipsisText.setString(base);
		ellipsisClock.restart();
	}
	window->clear(Color::Black);

	if (!loadingFrames.empty() && frameClock.getElapsedTime() > timePerFrame) {
		currentFrameIndex = (currentFrameIndex + 1) % loadingFrames.size();
		loadingSprite.setTexture(loadingFrames[currentFrameIndex], true);
		frameClock.restart();
	}

	if (loadingSprite.getTexture() != nullptr) {
		window->draw(loadingSprite);
	}
	else {
		if (fadeClock.getElapsedTime().asSeconds() >= 12 && creditsIndex < 1) {
			creditsIndex++;
			fadeClock.restart();
		}
		if (fadeClock.getElapsedTime().asSeconds() / 8.f <= 1.f) {
			float prog = fadeClock.getElapsedTime().asSeconds() / 4.f;
			if (prog >= 1.f) {
				prog = 1.f;
			}
			Uint8 alpha = static_cast<Uint8>(prog * 255);
			credits[creditsIndex].setColor(Color(255, 255, 255, alpha));
		}
		else {
			float prog = (fadeClock.getElapsedTime().asSeconds() - 8.f) / 4.f;
			if (prog >= 1.f) {
				prog = 1.f;
			}
			Uint8 alpha = static_cast<Uint8>(255 - (prog * 255));
			credits[creditsIndex].setColor(Color(255, 255, 255, alpha));
		}
		window->draw(credits[creditsIndex]);
	}

	window->draw(loadingEllipsisText);
	window->display();
}

//Private functions
void Game::reset()
{
	if (currentState == PLAYING) {
		fadeImg.update(*window);
		fadeDraw.setTexture(fadeImg);
		currentState = RESTARTING_FADE_OUT;
		fadeClock.restart();
	}
}

bool Game::loadRoadGraph(const string& filename)
{
	ifstream inFile(filename);
	if (!inFile.is_open()) {
		return false;
	}

	cout << "Loading road graph from cache file: " << filename << "..." << endl;
	roadGraph.clear(); // Ensure we start with a fresh graph

	string line;
	while (getline(inFile, line)) {
		if (line.empty()) continue;
		stringstream ss(line);
		Vector2f sourceNode;
		char colon;
		ss >> sourceNode.x >> sourceNode.y >> colon;

		vector<Vector2f> neighbors;
		Vector2f neighborNode;
		while (ss >> neighborNode.x >> neighborNode.y) {
			neighbors.push_back(neighborNode);
		}
		roadGraph[sourceNode] = neighbors;
	}
	inFile.close();
	cout << "Graph loaded successfully from cache." << endl;
	return !roadGraph.empty();
}

void Game::prompt()
{
	if (siren.getStatus() == Sound::Playing) {
		siren.stop();
	}
	this->window->clear(Color::Green);
	this->window->draw(city);
	this->window->draw(rd);
	signals->drawsignals(*window, 1, 1);
	signals->signalctrl(*window, RENDER_WORLD_SCALE_X, RENDER_WORLD_SCALE_Y);
	Text choose, st, en;
	choose.setString("Choose The Starting point ->");
	choose.setFont(disp);
	choose.setPosition(window->getSize().x / 2.f - 25 * (choose.getLetterSpacing() + choose.getString().getSize()) / 2, 100);
	choose.setOutlineColor(Color::Black);
	choose.setOutlineThickness(1.f);
	choose.setCharacterSize(40);
	st.setString(((start != -1) ? to_string(start) : myTextString));
	st.setFont(disp);
	st.setPosition(700, 200);
	st.setOutlineColor(Color::Black);
	st.setOutlineThickness(1.f);
	en.setString(((start == -1) ? "" : ((end == -1) ? myTextString : to_string(end))));
	en.setFont(disp);
	en.setPosition(1000, 200);
	en.setOutlineColor(Color::Black);
	en.setOutlineThickness(1.f);
	for (int i = 0;i < Signal::points.size();i++) {
		Text num;
		num.setFont(disp);
		num.setPosition(Vector2f(Signal::points[i].x - num.getCharacterSize() / 4, Signal::points[i].y - num.getCharacterSize() / 1.45));
		num.setOutlineColor(Color::Black);
		num.setOutlineThickness(1.f);
		num.setString(to_string(i + 1));
		window->draw(num);
	}
	this->window->draw(choose);
	this->window->draw(st);
	this->window->draw(en);
	for (Vector2f co : circles) {
		CircleShape c(2.f);
		c.setPosition(co.x - 2.f, co.y - 2.f);
		c.setFillColor(Color::Red);
		window->draw(c);
	}
	if (isAnimatingPath) {
		for (const auto& arrowSprite : pathArrowSprites) {
			this->window->draw(arrowSprite);
		}
	}
	fadeImg.update(*window);
	fadeDraw.setTexture(fadeImg);
}

void Game::playing()
{
	this->window->clear(Color::Green);
	this->window->setView(view);
	if (this->map) {
		this->window->draw(*map);
	}

	renderCarWithMasking(plr);
	updatePoliceCar();

	RandomCars->drawCars(*window, RENDER_WORLD_SCALE_X, RENDER_WORLD_SCALE_Y, plr, speed, collided, playerVelocity);
	signals->drawsignals(*window, RENDER_WORLD_SCALE_X, RENDER_WORLD_SCALE_Y);
	signals->signalctrl(*window, RENDER_WORLD_SCALE_X, RENDER_WORLD_SCALE_Y);

	Sprite ers = pathArrowSprites[(progIndex < pathArrowSprites.size()) ? progIndex : 0];
	ers.setScale(1.1, 1.1);
	ers.setPosition(ers.getPosition().x * RENDER_WORLD_SCALE_X, ers.getPosition().y * RENDER_WORLD_SCALE_Y);
	if (plr.getGlobalBounds().intersects(ers.getGlobalBounds())) progIndex++;

	window->setView(minimap.minimapView);
	RectangleShape b(Vector2f(1920.f, 1080.f));
	b.setFillColor(Color(200, 200, 200, 220));
	b.setPosition(minimap.minimapView.getCenter().x - minimap.minimapView.getSize().x / 2.f, minimap.minimapView.getCenter().y - minimap.minimapView.getSize().y / 2.f);
	window->draw(b);
	window->draw(minimap.minimapBackgroundSprite);
	for (int i = progIndex;i < pathArrowSprites.size();i++) {
		window->draw(pathArrowSprites[i]);
	}
	for (int i = 0;i < Signal::points.size();i++) {
		Text num;
		num.setFont(disp);
		num.setPosition(Vector2f(Signal::points[i].x - num.getCharacterSize() / 4, Signal::points[i].y - num.getCharacterSize() / 1.4));
		num.setOutlineColor(Color::Black);
		num.setOutlineThickness(1.f);
		num.setString(to_string(i + 1));
		window->draw(num);
	}
	
	window->draw(minimap.playerDotSprite);
	window->draw(minimap.policeDotSprite);
	// Draw the minimap border (using the default view)
	window->setView(window->getDefaultView());
	window->draw(minimap.minimapBorder);
	minimap.setcenter(plr.getPosition().x * (1920.f / 29335.f), plr.getPosition().y * (1080.f / 16504.f));
	if (expand) window->draw(cancelbtn);

	int getTime = Jikan.asSeconds() - timer.getElapsedTime().asSeconds();
	if (Signal::intercept.getElapsedTime().asSeconds() >= Jikan.asSeconds() / 2.f && currentState == PLAYING) {
		Signal::jam = true;
		Signal::intercept.restart();
	}

	if (getTime <= 0 && currentState == PLAYING) {
		getTime = 0;
		currentState = GameOver;
	}
	if (currentState == PLAYING) {
		if ((plc.getPosition().x > 29335.f || plc.getPosition().x < 0.f || plc.getPosition().y > 16504.f || plc.getPosition().y < 0.f) && !isPoliceChaseActive) {
			float ang = this->plc.getRotation();
			float dx = policeSpeed * cosf(ang * pi / 180.f);
			float dy = policeSpeed * sinf(ang * pi / 180.f);
			plc.move(dx, dy);
		}
		else if (!isPoliceChaseActive){
			spawnPoliceCar();
			if (siren.getStatus() != Sound::Playing) {
				Vector2f dis = plr.getPosition() - plc.getPosition();
				siren.setVolume(100.f * (1 - sqrt(dis.x * dis.x + dis.y * dis.y) / 10000.f));
				siren.play();
			}	
		}
	}

	if (getTime <= 10) {
		ElapsedTime.setFillColor(Color::Red);
	}

	// Display the remaining time
	int hrs = getTime / 3600;
	int mnts = (getTime % 3600) / 60;
	int sec = getTime % 60;

	ElapsedTime.setString(to_string(hrs) + " : " + to_string(mnts) + " : " + to_string(sec % 60));
	ans.setString(signalPoint);
	if (Signal::jam) {
		window->draw(select);
		window->draw(ans);
	}
	else if (selecting) {
		bool done = true;
		for (int i = 0;i < 4;i++) {
			d4[i].setPosition(window->getSize().x / 2.f + 70.f * (i % 2) * (i < 2 ? -1 : 1), window->getSize().y / 3.f + 70.f * (i % 2 == 0) * (i < 2 ? -1 : 1));
			if (d4[i].getString() == "0") d4[i].setFillColor(Color::Red);
			else if (d4[i].getString() == "1") d4[i].setFillColor(Color::Green);
			window->draw(d4[i]);
			if (d4[i].getString() == "_") done = false;
		}
		if (done) {
			for (int i = 0;i < 4;i++) {
				int point_number = stoi(signalPoint) - 1;
				if (stoi((string)d4[i].getString()) == 0) {
					Signal::stop[point_number][i] = true;
					Signal::warn[point_number][i].restart();
				}
				else Signal::stop[point_number][i] = false;
			}
			selecting = false;
			d4.clear();
		}
		Signal::intercept.restart();
	}
	if (Signal::intercept.getElapsedTime().asSeconds() >= 15.f && !signalPoint.empty()) {
		Signal::selected[stoi(signalPoint)] = false;
		signalPoint.clear();
	}
	window->draw(ElapsedTime);
	fadeImg.update(*window);
	fadeDraw.setTexture(fadeImg);
}

void Game::renderCarWithMasking(Sprite& car)
{
	bool isOnBridge = false;

	if (&car == &plr) {
		plrIsOnBridge = false;
		isOnBridge = plrIsOnBridge;
	}
	else {
		plcIsOnBridge = false;
		isOnBridge = plcIsOnBridge;
	}
	const Transform& carTransform = car.getTransform();
	FloatRect carBounds = car.getLocalBounds(); // Use local bounds before transformation

	// Define the points on the car we want to check (in its own local space)
	vector<Vector2f> checkPoints;
	checkPoints.push_back({ carBounds.width, carBounds.height / 2.f }); // Middle of the front bumper
	checkPoints.push_back({ 0.f, carBounds.height / 2.f });             // Middle of the rear bumper
	checkPoints.push_back({ carBounds.width / 2.f, 0.f });              // Top-middle of the roof
	checkPoints.push_back({ carBounds.width / 2.f, carBounds.height }); // Bottom-middle of the chassis

	// Convert these local points to their current world positions
	vector<Vector2f> worldCheckPoints;
	for (const auto& p : checkPoints) {
		worldCheckPoints.push_back(carTransform.transformPoint(p));
	}

	for (const auto& curr : shapes)
	{
		bool isAnyPointInside = false;
		// Check if ANY of our car's points are inside the bridge area.
		for (const auto& point : worldCheckPoints) {
			if (isPointInsideConvexShape(point, curr.area)) {
				isAnyPointInside = true;
				isOnBridge = true;
				(&car == &plr) ? currentShape = &curr : plcCurrentShape = &curr;
				break; // Found one point inside, no need to check others
			}
		}

		if (isAnyPointInside)
		{
			for (const auto& entryPoint : curr.entryPoints)
			{
				if (car.getGlobalBounds().contains(entryPoint)) {
					if (&car == &plr)
						entered = true;
					else plcentered = true;
					break;
				}
			}
			if (&car == &plr) {
				if (entered) break;
			}
			else {
				if (plcentered) break;
			}
		}
	}
	if (!isOnBridge) {
		if (&car == &plr) entered = false;
		else plcentered = false;
	}
	if ((&car == &plr && entered) || (plcentered && &car == &plc) || !isOnBridge)
	{
		this->window->draw(car);
	}
	else
	{
		glEnable(GL_STENCIL_TEST);
		// 2. Clear the stencil buffer ONLY for this operation
		glClear(GL_STENCIL_BUFFER_BIT);
		// 3. Draw the bridge shape to the stencil buffer to create the mask
		glStencilFunc(GL_ALWAYS, 1, 0xFF);
		glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
		glStencilMask(0xFF);
		glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE); // Don't draw the shape to the screen
		this->window->draw((&car == &plr ? currentShape->area : plcCurrentShape->area));
		glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE); // Re-enable color drawing
		// 4. Set the stencil function to draw the car ONLY where the stencil is NOT 1
		glStencilFunc(GL_NOTEQUAL, 1, 0xFF);
		glStencilMask(0x00); // Don't write to the stencil buffer anymore
		// 5. Draw the car. It will be "punched out" by the mask.
		this->window->draw(car);
        // 6. Disable the stencil test to clean up the state for the next car.
		glDisable(GL_STENCIL_TEST);
	}
}

//Constructors & Destructors
Game::Game() : railing() {
	map = nullptr;
	window = nullptr;
	RandomCars = make_unique<Cars>(29335.f, 16504.f);
	signals = make_unique<Signal>();
	currentState = LOADING;
	initMinimal();

	isLoadingFinished = false;
	loadingThread = thread([this]() { this->loadAssetsAndData(); });

	while (window->isOpen() && !isLoadingFinished) {
		Event event;
		while (window->pollEvent(event)) {
			if (event.type == Event::Closed) {
				window->close();
			}
		}
		{
			lock_guard<mutex> lock(loadingMutex);
			if (isLoadingFinished) break;
		}
		updateAndDrawLoadingAnimation();
	}

	if (loadingThread.joinable()) {
		loadingThread.join();
	}
	fadeImg.update(*window);
	fadeDraw.setTexture(fadeImg);
	currentState = FADING_OUT;
}

Game::~Game() {
	delete this->window;
	delete this->map;
}

const bool Game::getWinOpen() const
{
	return this->window->isOpen();
}

void Game::pollEvents()
{
	while (this->window->pollEvent(this->ev)) {
		switch (ev.type)
		{
		case Event::Closed:
			this->window->close();
			break;

		case Event::KeyPressed:
			if (this->ev.key.code == Keyboard::Escape)
				this->window->close();
			if (currentState == PROMPT && ev.key.code == Keyboard::Enter) {
				if (start == -1 && !myTextString.empty()) {
					start = stoi(myTextString);
					myTextString.clear();
				}
				else if (end == -1 && !myTextString.empty()) {
					end = stoi(myTextString);
					myTextString.clear();
					if (start != -1 && end != -1) {
						findPath(start, end);
					}
				}
			}
			if (this->ev.key.code == Keyboard::R && currentState != PROMPT) {
				reset();
			}
			if (Signal::jam && !selecting && ev.key.code == Keyboard::Enter && !signalPoint.empty()) {
				int point_number = stoi(signalPoint);
				int point_index = point_number - 1; // <-- THE FIX: Convert to 0-based index

				// Safety check
				if (point_index >= 0 && point_index < Signal::selected.size()) {
					Signal::selected[point_index] = true; // Use the safe index
					Signal::jam = false;
					selecting = true;
					d4.assign(4, Text("_", disp, 40)); // Initialize the vector properly
					idx = 0;
				}
			}
			
			break;

		case Event::TextEntered:
			if (currentState == PROMPT) {
				Uint32 unicodeChar = ev.text.unicode;

				if (unicodeChar >= 48 && unicodeChar <= 57 && myTextString.size() < 2)
				{
					if (stoi(myTextString + static_cast<char>(unicodeChar)) < 21 && stoi(myTextString + static_cast<char>(unicodeChar)) != start)
						myTextString += static_cast<char>(unicodeChar);
				}
				else if (unicodeChar == 8)
				{
					if (!myTextString.empty())
					{
						myTextString.erase(myTextString.size() - 1);
					}
				}
			}
			if (Signal::jam) {
				Uint32 unicodeChar = ev.text.unicode;
				if (unicodeChar >= '1' && unicodeChar <= '7' && signalPoint.size() < 1)
				{
					if (stoi(signalPoint + static_cast<char>(unicodeChar)) <= Signal::selected.size())
						signalPoint += static_cast<char>(unicodeChar);
				}
				else if (unicodeChar == 8)
				{
					if (!signalPoint.empty())
					{
						signalPoint.erase(signalPoint.size() - 1);
					}
				}
			}
			if (selecting) {
				Uint32 unicodeChar = ev.text.unicode;
				if (unicodeChar >= 48 && unicodeChar <= 49 && tog.size() < 1)
				{
					if (stoi(tog + static_cast<char>(unicodeChar)) < 2) {
						d4[idx].setString(tog + static_cast<char>(unicodeChar));
						idx = (++idx % 4);
						tog.clear();
					}
				}
			}
			break;

		case Event::MouseButtonPressed:
			Vector2i mousepos = Mouse::getPosition();
			FloatRect area(1920 * 0.75f, 1080 * 0.05f, 1920 * 0.2f, 1080 * 0.2f);
			FloatRect close(cancelbtn.getPosition().x, cancelbtn.getPosition().y + 1080 * 0.05f, cancelbtn.getGlobalBounds().width, cancelbtn.getGlobalBounds().height);

			if (area.contains(Vector2f(mousepos)) && !expand) {
				expand = true;
				minimap.expand();
			}
			else if (close.contains(Vector2f(mousepos))) {
				expand = false;
				minimap.reset();
			}
			break;
		}
	}
}

//void Game::buildComplexRoadGraph()
//{
//	cout << "Starting complex graph build..." << endl;
//	const int searchRadius = 1; // Connects nearby pixels of the same color.
//	unordered_set<Vector2f, Vector2fHash> cnt;
//	vector<Vector2f> dir = { {1,0},{0,1},{-1,0},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
//	for (const auto& coord : path) cnt.insert(coord);
//	for (const auto& coord : path) {
//		for (int i = 0;i < dir.size();++i) {
//			bool connected = false;
//			float dx = dir[i].x;
//			float dy = dir[i].y;
//			Vector2f neighbor = coord + Vector2f(dx, dy);
//			if (green.count(neighbor)) {
//				roadGraph[coord].push_back(neighbor + Vector2f(dx, dy));
//			}
//			else if (cnt.count(neighbor)) {
//				roadGraph[coord].push_back(neighbor);
//			}
//			
//		}
//	}
//	ifstream cr("CurveCon.txt"),rr("Rewrite.txt"),in("InterCon.txt");
//	float a, b, c, d;
//	while (rr >> a >> b) roadGraph[{a, b}].clear();
//	rr.close();
//	while (in >> a >> b) roadGraph[{a, b}].clear(); in.close();
//	ifstream nn("InterCon.txt");
//	vector<Vector2f> connect;
//	while (nn >> a >> b) {
//		connect.push_back({ a, b });
//		if (connect.size() == 2) {
//			roadGraph[connect[0]].push_back(connect[1]);
//			roadGraph[connect[1]].push_back(connect[0]);
//			for (int i = 0;i < 2;i++) {
//				for (int j = 0;j < 4;j++) {
//					Vector2f next = connect[i] + dir[j];
//					if (cnt.count(next)) roadGraph[connect[i]].push_back(next);
//				}
//				
//			}
//			connect.clear();
//		}
//	}nn.close();
//	while (cr >> a >> b >> c >> d) {
//		roadGraph[{a, b}].push_back({ c,d });
//		roadGraph[{c, d}].push_back({ a,b });
//	}
//	cr.close();
//	cout << "Graph build finished." << endl;
//	string name = "RoadGraphNew.cache";
//	saveRoadGraph(name);
//}
//
//void Game::saveRoadGraph(const string& filename)
//{
//	ofstream outFile(filename);
//	if (!outFile.is_open()) {
//		cerr << "Error: Could not open file to save graph cache: " << filename << endl;
//		return;
//	}
//
//	cout << "Saving road graph to cache file: " << filename << "..." << endl;
//
//	// The file format will be:
//	// NodeX NodeY : Neighbor1X Neighbor1Y Neighbor2X Neighbor2Y ...
//	for (const auto& [node, neighbors] : roadGraph) {
//		outFile << node.x << " " << node.y << " :";
//		for (const auto& neighbor : neighbors) {
//			outFile << " " << neighbor.x << " " << neighbor.y;
//		}
//		outFile << "\n";
//	}
//
//	outFile.close();
//	cout << "Graph saved successfully." << endl;
//}

void Game::update()
{
	this->pollEvents();
	if (isAnimatingPath) {
		if (pathAnimTimer.getElapsedTime() > pathAnimInterval && pathAnimationIndex < shortestPath.size()) {
			if (pathAnimationIndex < shortestPath.size() - 18) {
				Sprite newArrow;
				newArrow.setTexture(ar);
				newArrow.setScale(0.03, 0.03);
				newArrow.setOrigin(ar.getSize().x / 2.f, ar.getSize().y / 2.f);

				const Vector2f& currentPoint = shortestPath[pathAnimationIndex];
				const Vector2f& nextPoint = shortestPath[pathAnimationIndex + 18];

				newArrow.setPosition(currentPoint);
				Vector2f direction = nextPoint - currentPoint;
				float angle = atan2(direction.y, direction.x) * 180.f / pi;
				newArrow.setRotation(angle);

				pathArrowSprites.push_back(newArrow);
				plr.setPosition(pathArrowSprites[0].getPosition().x * RENDER_WORLD_SCALE_X, pathArrowSprites[0].getPosition().y * RENDER_WORLD_SCALE_Y);
				plr.setRotation(pathArrowSprites[0].getRotation());
				plr.setPosition(plr.getPosition().x - plr.getGlobalBounds().width * 10 * cosf(plr.getRotation() * pi / 180.f), plr.getPosition().y - plr.getGlobalBounds().width * 10 * sinf(plr.getRotation() * pi / 180.f));
				plc.setRotation(pathArrowSprites[0].getRotation());
				policeSpeed = 5.f;
				plc.setPosition(plr.getPosition().x - Jikan.asSeconds() * 30.f * policeSpeed * cosf(plc.getRotation() * pi / 180.f), plr.getPosition().y - Jikan.asSeconds() * 30.f * policeSpeed * sinf(plc.getRotation() * pi / 180.f));
				speed = 4.f;
			}
			pathAnimationIndex += 18;
			pathAnimTimer.restart();
		}

		if (pathAnimationIndex >= shortestPath.size()) {
			isAnimatingPath = false;
			currentState = FADING_OUT;
			fadeClock.restart();
			pathAnimTimer.restart();
		}
	}

	if (spawnDelay.getElapsedTime().asSeconds() >= 10) {
		RandomCars->AddCars();
		RandomCars->Spawn();
		spawnDelay.restart();
	}

	switch (currentState)
	{
	case GameOver:
	{
		currentState = RESTARTING_FADE_OUT;
		break;
	}
	case PROMPT: 
	{
		break;
	}

	case FADING_OUT:
	{
		// Calculate progress (0.0 to 1.0)
		float progress = fadeClock.getElapsedTime().asSeconds() / fadeDuration.asSeconds();
		if (progress > 1.0f) {
			progress = 1.0f;
		}

		// Fade from transparent (0) to opaque (255)
		Uint8 alpha = static_cast<Uint8>(progress * 255);
		fadeShape.setFillColor(Color(0, 0, 0, alpha));

		// When fully faded out...
		if (progress >= 1.0f) {
			if (state == 1) prompt();
			else {
				const Vector2f mapSize(29335.0f, 16504.0f);
				view.setSize(4800, 2700);
				Vector2f viewSize = view.getSize();
				Vector2f desiredCenter = plr.getPosition();
				float minX = viewSize.x / 2.0f;
				float maxX = mapSize.x - viewSize.x / 2.0f;
				float minY = viewSize.y / 2.0f;
				float maxY = mapSize.y - viewSize.y / 2.0f;
				view.setCenter(
					clamp(desiredCenter.x, minX, maxX),
					clamp(desiredCenter.y, minY, maxY)
				);
				playing();
				timer.restart();
			}
			currentState = FADING_IN;
			fadeClock.restart();
			spawnDelay.restart();
			Signal::intercept.restart();
		}
		break;
	}

	case FADING_IN:
	{
		float progress = fadeClock.getElapsedTime().asSeconds() / fadeDuration.asSeconds();
		if (progress > 1.f) {
			progress = 1.f;
		}

		Uint8 alpha = static_cast<Uint8>(255 - (progress * 255));
		fadeShape.setFillColor(Color(0, 0, 0, alpha));

		if (progress >= 1.f) {
			if (state == 1) {
				prompt();
				currentState = PROMPT;
			}
			else {
				Signal::intercept.restart();
				timer.restart();
				ElapsedTime.setFillColor(Color::White);
				playing();
				fadeImg.update(*window);
				fadeDraw.setTexture(fadeImg);
				Signal::intercept.restart();
				currentState = PLAYING;
			}
		}
		break;
	}
	case PLAYING:
	{
		if (!caught) {
			if (Keyboard::isKeyPressed(Keyboard::Up)) {
				if (this->speed < 10)
					this->speed += 0.003;
				else this->speed = 10;
			}
			if (Keyboard::isKeyPressed(Keyboard::Right)) {
				plr.rotate(1.055);
			}
			if (Keyboard::isKeyPressed(Keyboard::Left)) {
				plr.rotate(-(1.055));
			}
		}
		Vector2f playerPrevPos = plr.getPosition();

		// --- STEP 3: APPLY MOVEMENT ---
		plr.move(playerVelocity);
		plr.rotate(playerSpin);

		// --- STEP 4: COLLISION DETECTION & RESPONSE ---
		CollisionInfo playerCollision = railing.checkBorders(plr, playerVelocity);

		if (playerCollision.collided && !playerInCrashState) {
			playerInCrashState = true;

			Vector2f carDir = normalize(playerVelocity);

			// Calculate the angle between the car's direction and the wall's normal
			float impactDot = dot(carDir, playerCollision.railingNormal);
			// acos gives the angle in radians. Convert to degrees.
			float impactAngle = acos(abs(impactDot)) * 180.f / pi;

			// --- CRITICAL ANGLE LOGIC ---
			if (impactAngle < 45.f) { // Angle is relative to the normal, so < 45 is a "head-on" collision
				playerVelocity = -2.f * (impactAngle / 90.f) * playerVelocity; // Dead stop
				speed = (-(float)speed * 0.98);
				// Apply a small "rebound" rotation away from the wall
				float cross = carDir.x * playerCollision.railingNormal.y - carDir.y * playerCollision.railingNormal.x;
				playerSpin = (cross > 0 ? -(impactAngle) : impactAngle); // Rotate away
			}
			// --- GLANCING BLOW LOGIC ---
			else {
				// Reflect velocity along the wall
				playerVelocity = playerVelocity - dot(playerVelocity, playerCollision.railingNormal) * playerCollision.railingNormal;

				// Calculate the rotation needed to align with the wall
				float wallAngle = atan2(playerCollision.wallDirection.y, playerCollision.wallDirection.x) * 180.f / pi;
				float carAngle = plr.getRotation();
				float angleDiff = wallAngle - carAngle;
				while (angleDiff > 180) angleDiff -= 360;
				while (angleDiff < -180) angleDiff += 360;

				// Apply a fraction of the difference as spin to smoothly align
				playerSpin = angleDiff * 0.02f;
			}

			// Correct position to prevent sinking
			plr.setPosition(playerPrevPos);
		}

		// --- STEP 5: POST-COLLISION PHYSICS (FRICTION) ---
		if (playerInCrashState) {
			playerVelocity *= 0.98f;
			playerSpin *= 0.9f; // Make spin decay a bit faster

			if (sqrt(dot(playerVelocity, playerVelocity)) < 0.5f && abs(playerSpin) < 0.5f) {
				playerInCrashState = false;
				playerSpin = 0.f;
				speed = 1.f;
			}
		}
		else if (collided) {
			playerVelocity.x *= 0.9;
			playerVelocity.y *= 0.9;

			// Exit the collision state if the spin is negligible
			if (playerVelocity.x * playerVelocity.x + playerVelocity.y * playerVelocity.y < 0.2f) {
				playerVelocity = { 1.f * cosf(plr.getRotation() * pi / 180.f), 1.f * sinf(plr.getRotation() * pi / 180.f) };
				collided = false;
			}
		}
		else {
			float angle = plr.getRotation() * pi / 180.f;
			float dx = cosf(angle) * speed;
			float dy = sinf(angle) * speed;
			playerVelocity = { dx, dy };
		}

		if (!signalPoint.empty() && Signal::intercept.getElapsedTime().asSeconds() >= Jikan.asSeconds() / 3.f) {
			Signal::selected[stoi(signalPoint) - 1] = false;
			signalPoint.clear();
		}
		if (Keyboard::isKeyPressed(Keyboard::Down)) {
			this->speed = max(speed - 0.015, -5.0);
		}

		if (Keyboard::isKeyPressed(Keyboard::Down) && this->speed > 0.0f) {
			if (playerBrakeSound.getStatus() != Sound::Playing) {
				playerBrakeSound.play();
			}
		}
		else if (playerBrakeSound.getStatus() == Sound::Playing) {
			playerBrakeSound.stop();
		}

		if (this->speed > 0.1f) {
			if (playerEngineSound.getStatus() != Sound::Playing) {
				playerEngineSound.play();
			}
			float max_speed = 10.f;
			float pitch = 1.0f + (this->speed / max_speed);
			playerEngineSound.setPitch(pitch);

		}
		else {
			if (playerEngineSound.getStatus() == Sound::Playing) {
				playerEngineSound.stop();
			}
		}

		double fact = fabs(speed);
		const Vector2f mapSize(29335.0f, 16504.0f);
		view.setSize(960 * (1 + fact), 540 * (1 + fact));
		Vector2f viewSize = view.getSize();

		Vector2f desiredCenter = plr.getPosition();

		Vector2f finalCenter = desiredCenter;

		float minX = viewSize.x / 2.0f + 2.f;
		float maxX = (mapSize.x - viewSize.x / 2.0f) - 2.f;
		finalCenter.x = max(minX, min(finalCenter.x, maxX));

		float minY = viewSize.y / 2.0f + 2.f;
		float maxY = (mapSize.y - viewSize.y / 2.0f) - 2.f;
		finalCenter.y = max(minY, min(finalCenter.y, maxY));

		view.setCenter(finalCenter);

		//A red dot marking the position of the Player in the MiniMap
		minimap.playerDotSprite.setPosition((plr.getPosition().x + 96.f * cosf(plr.getRotation() * pi / 180.f)) * (1920.f / 29335.f), (plr.getPosition().y + 96.f * sinf(plr.getRotation()) * pi / 180.f) * (1080.f / 16504.f));
		minimap.policeDotSprite.setPosition(plc.getPosition().x * (1920.f / 29335.f), plc.getPosition().y * (1080.f / 16504.f));
		break;
	}
	case RESTARTING_FADE_OUT:
	{
		float progress = fadeClock.getElapsedTime().asSeconds() / fadeDuration.asSeconds();
		if (progress > 1.0f) {
			progress = 1.0f;
		}

		// Fade from transparent (0) to opaque (255)
		Uint8 alpha = static_cast<Uint8>(progress * 255);
		fadeShape.setFillColor(Color(0, 0, 0, alpha));
		if (siren.getStatus() == Sound::Playing) {
			siren.setVolume(siren.getVolume() - 10);
			if (siren.getVolume() < 1) siren.stop();
		}
		// When fully black...
		if (progress >= 1.0f) {
			Signal::resetMem();
			RandomCars = make_unique<Cars>(29335.f, 16504.f);
			signals = make_unique<Signal>();
			plr.setPosition(endpoints[0]);
			plc.setPosition(endpoints[0]);
			minimap.playerDotSprite.setPosition((plr.getPosition().x + 96.f * cosf(plr.getRotation() * pi / 180.f))* (1920.f / 29335.f), (plr.getPosition().y + 96.f * sinf(plr.getRotation()) * pi / 180.f)* (1080.f / 16504.f));
			minimap.policeDotSprite.setPosition(plc.getPosition().x* (1920.f / 29335.f), plc.getPosition().y* (1080.f / 16504.f));
			prompt();
			start = -1;
			end = -1;
			myTextString.clear();
			caught = false;
			isPoliceChaseActive = false;
			currentState = RESTARTING_FADE_IN;
			shortestPath.clear();
			pathArrowSprites.clear();
			progIndex = 0;
			isAnimatingPath = false;
			pathAnimationIndex = 0;
			speed = 0.f;
			currentShape = nullptr;
			plcCurrentShape = nullptr;
			timer.restart();
			Jikan = seconds(0);
			fadeClock.restart();
		}
		break;
	}
	case RESTARTING_FADE_IN:
	{
		float progress = fadeClock.getElapsedTime().asSeconds() / fadeDuration.asSeconds();
		if (progress > 1.0f) {
			progress = 1.0f;
		}

		Uint8 alpha = static_cast<Uint8>(255 - (progress * 255));
		fadeShape.setFillColor(Color(0, 0, 0, alpha));

		if (progress >= 1.0f) {
			window->setView(window->getDefaultView());
			currentState = PROMPT;
		}
		break;
	}
	}
}

void Game::findPath(int x, int y)
{
	Vector2f startNode = endpoints[x];
	Vector2f endNode = endpoints[y];

	this->shortestPath = findShortestPath(startNode, endNode);
	if (!shortestPath.empty()) {
		isAnimatingPath = true;
		pathAnimationIndex = 0;
		pathArrowSprites.clear();
		pathAnimTimer.restart();
	}
	else {
		isAnimatingPath = false;
	}
}

vector<Vector2f> Game::findShortestPath(const Vector2f& start, const Vector2f& end)
{
	if (roadGraph.find(start) == roadGraph.end() || roadGraph.find(end) == roadGraph.end()) {
		cout << "Start or end node not in graph." << endl;
		return {};
	}

	queue<Vector2f> q;
	unordered_map<Vector2f, Vector2f, Vector2fHash> parent;
	unordered_set<Vector2f, Vector2fHash> visited;

	q.push(start);
	visited.insert(start);

	bool found = false;
	while (!q.empty()) {
		Vector2f current = q.front();
		q.pop();

		if (current == end) {
			found = true;
			break;
		}
		for (const auto& neighbor : roadGraph[current]) {
			if (visited.find(neighbor) == visited.end()) {
				visited.insert(neighbor);
				parent[neighbor] = current;
				q.push(neighbor);
			}
		}
	}
	vector<Vector2f> path;
	if (found) {
		Vector2f current = end;
		while (current != start) {
			path.push_back(current);
			current = parent[current];
		}
		path.push_back(start);
		reverse(path.begin(), path.end());
	}
	else {
		cout << "No path found." << endl;
	}
	float Total = 0;
	for (int i = 0;i < path.size() - 1;i++) {
		Vector2f dis = path[i + 1] - path[i];
		Total += sqrt(dis.x * dis.x + dis.y * dis.y);
	}
	if (currentState == PROMPT) Jikan = seconds(Total / 30);

	return path;
}

void Game::render()
{
	this->window->clear(Color::Green);
	if (currentState == PROMPT) {
		prompt();
		state = 4;
	}
	else if (currentState == FADING_OUT || currentState == RESTARTING_FADE_IN || currentState == RESTARTING_FADE_OUT || currentState == FADING_IN) {
		if (currentState == RESTARTING_FADE_OUT) playing();
		this->window->draw(fadeDraw);
		this->window->draw(fadeShape);
	}
	else if (currentState == PLAYING) {
		playing();
		state = 1;
	}
	this->window->display();
}

Vector2f Game::findNearestRoadNode(const Vector2f& worldPosition, Sprite& car)
{
	Vector2f mapPosition = {
		worldPosition.x / (float)RENDER_WORLD_SCALE_X,
		worldPosition.y / (float)RENDER_WORLD_SCALE_Y
	};

	Vector2f closestNode = endpoints[0]; // Default to first endpoint
	float minDistanceSq = -1.f;

	// Iterate through all nodes in your graph to find the closest one
	for (const auto& pair : roadGraph) {
		const Vector2f& node = pair.first;
		float dx = mapPosition.x - node.x;
		float dy = mapPosition.y - node.y;
		float distSq = dx * dx + dy * dy;

		if (minDistanceSq < 0 || distSq < minDistanceSq) {
			if (&car == &plr) {
				if (plrIsOnBridge && entered) {
					if (!searchlimit.count(node)) {
						minDistanceSq = distSq;
						closestNode = node;
					}
				}
				else if (plrIsOnBridge && !entered) {
					if (searchlimit.count(node)) {
						minDistanceSq = distSq;
						closestNode = node;
					}
				}
				else {
					minDistanceSq = distSq;
					closestNode = node;
				}
			}
			else {
				if (plcIsOnBridge && plcentered) {
					if (!searchlimit.count(node)) {
						minDistanceSq = distSq;
						closestNode = node;
					}
				}
				else if (plcIsOnBridge && !plcentered) {
					if (searchlimit.count(node)) {
						minDistanceSq = distSq;
						closestNode = node;
					}
				}
				else {
					minDistanceSq = distSq;
					closestNode = node;
				}
			}
			
		}
	}
	return closestNode;
}

void Game::spawnPoliceCar()
{
	policePathTimer.restart();
	isPoliceChaseActive = true;

	policePath.clear();
	policePathIndex = 0;
}

// In Game.cpp

void Game::updatePoliceCar()
{
	if (!isPoliceChaseActive) return;
	renderCarWithMasking(plc);
	const float MAX_SIREN_DISTANCE = 10000.f;
	const float MAX_SIREN_DISTANCE_SQUARED = MAX_SIREN_DISTANCE * MAX_SIREN_DISTANCE;
	Vector2f dis = plr.getPosition() - plc.getPosition();
	float distSq = dis.x * dis.x + dis.y * dis.y;
	float volumeRatio = 1.0f - (distSq / MAX_SIREN_DISTANCE_SQUARED);
	if (volumeRatio < 0) volumeRatio = 0;
	siren.setVolume(100.f * volumeRatio);

	const Transform& plcTransform = plc.getTransform();
	FloatRect plcBounds = plc.getLocalBounds();

	// Ray endpoints in the car's local space
	Vector2f front_center_local = { plcBounds.width, plcBounds.height / 2.f };
	Vector2f left_front_local = { plcBounds.width, 0.f };
	Vector2f right_front_local = { plcBounds.width, plcBounds.height };
	Vector2f left_side_local = { plcBounds.width / 2.f, -plcBounds.height }; // Side rays are wider
	Vector2f right_side_local = { plcBounds.width / 2.f, plcBounds.height * 2.f };

	// Convert local ray points to world coordinates
	Vector2f car_pos = plc.getPosition();
	Vector2f front_ray_end = plcTransform.transformPoint(front_center_local + Vector2f(600, 0)); // Long forward ray
	Vector2f left_lane_end = plcTransform.transformPoint(left_side_local + Vector2f(200, 0));  // Left check
	Vector2f right_lane_end = plcTransform.transformPoint(right_side_local + Vector2f(200, 0)); // Right check

	// Check for collisions along these rays
	bool carInFront = false;
	bool leftLaneBlocked = false;
	bool rightLaneBlocked = false;

	// Get a list of all other cars on screen to check against
	list<Car>& ai_cars = RandomCars->getMovingCars(); // You need to implement getMovingCars()
	for (const auto& otherCar : ai_cars) {
		if (lineIntersectsRect(car_pos, front_ray_end, otherCar.body.getGlobalBounds())) {
			carInFront = true;
		}
		if (lineIntersectsRect(car_pos, left_lane_end, otherCar.body.getGlobalBounds())) {
			leftLaneBlocked = true;
		}
		if (lineIntersectsRect(car_pos, right_lane_end, otherCar.body.getGlobalBounds())) {
			rightLaneBlocked = true;
		}
	}
	// Also check against the player!
	if (lineIntersectsRect(car_pos, left_lane_end, plr.getGlobalBounds())) leftLaneBlocked = true;
	if (lineIntersectsRect(car_pos, right_lane_end, plr.getGlobalBounds())) rightLaneBlocked = true;


	// --- AI DECISION MAKING ---
	// Only make a major decision (like changing lanes) every so often.

	if (policePathTimer.getElapsedTime().asSeconds() > 0.5f || policePath.empty()) {
		Vector2f policeCurrentNode = findNearestRoadNode(plc.getPosition(), plc);
		Vector2f playerTargetNode = findNearestRoadNode(plr.getPosition(), plr);
		vector<Vector2f> p = findShortestPath(policeCurrentNode, playerTargetNode);
		if (!p.empty()) {
			policePath = p;
			policePathIndex = 0;
		}
		policePathTimer.restart();
	}

	if (!policePath.empty()) {
		size_t targetNodeIndex = (policePath.size() > policePathIndex + 1) ? ++policePathIndex : policePathIndex;
		Vector2f targetWorldPos = {
			policePath[targetNodeIndex].x * (float)RENDER_WORLD_SCALE_X,
			policePath[targetNodeIndex].y * (float)RENDER_WORLD_SCALE_Y
		};
		Vector2f direction = targetWorldPos - (car_pos - offset);
		float angle = atan2(direction.y, direction.x) * 180.f / pi;
		if (policeDecisionTimer.getElapsedTime().asSeconds() > 1.0f && !isPoliceChangingLane) {
			if (carInFront) {
				// Obstacle ahead! Try to overtake.
				if (!leftLaneBlocked) {
					isPoliceChangingLane = true;
					// Calculate a target point in the adjacent lane
					offset = Vector2f(1.f * sinf(angle * pi / 180.f), -1.f * cosf(angle * pi / 180.f));
					policeDecisionTimer.restart();
				}
				else if (!rightLaneBlocked) {
					isPoliceChangingLane = true;
					offset = Vector2f(-1.f * sinf(angle * pi / 180.f), 1.f * cosf(angle * pi / 180.f));
					policeDecisionTimer.restart();
				}
			}
			else {
				isPoliceChangingLane = false;
			}
		}
		if (isPoliceChangingLane) {
			// If changing lanes, steer towards the lane change target		
			plc.move(offset);
		}
		
		plc.setRotation(angle);

		// SPEED CONTROL
		if (carInFront) {
			policeSpeed = max(0.0f, policeSpeed - 0.1f); // Slow down
		}
		else {
			policeSpeed = min(11.f, policeSpeed + 0.05f); // Speed up
		}

		float ang = plc.getRotation();
		plc.move(cosf(ang * pi / 180.f) * policeSpeed, sinf(ang * pi / 180.f) * policeSpeed);
	}
	Vector2f distanceToPlayer = plr.getPosition() - plc.getPosition();
	float catchDistanceSq = distanceToPlayer.x * distanceToPlayer.x + distanceToPlayer.y * distanceToPlayer.y;
	if (caught) {
		speed = max(0.0, speed - 0.02);
		if (speed == 0) {
			reset();
		}
	}
	if (catchDistanceSq < (250.f * 250.f)) {
		policeSpeed = speed;
		caught = true;
	}
}

//void Game::alignCar()
//{
//	Sprite left, right;
//	const Texture* tx = plc.getTexture();
//	left.setTexture(*tx);
//	left.setOrigin(plc.getOrigin());
//	left.setScale(plc.getScale());
//	left.setPosition(plc.getPosition().x + plc.getGlobalBounds().width * sinf(plc.getRotation() * pi / 180.f), plc.getPosition().y - plc.getGlobalBounds().width * cosf(plc.getRotation() * pi / 180.f));
//	left.setRotation(plc.getRotation());
//	right.setTexture(*tx);
//	right.setOrigin(plc.getOrigin());
//	right.setScale(plc.getScale());
//	right.setPosition(plc.getPosition().x - plc.getGlobalBounds().width * sinf(plc.getRotation() * pi / 180.f), plc.getPosition().y + plc.getGlobalBounds().width * cosf(plc.getRotation() * pi / 180.f));
//	bool lftStop = railing.checkBorders(left);
//	bool rtStop = railing.checkBorders(right);
//	if (!lftStop) dispPLC.move(1.f * sinf(plc.getRotation() * pi / 180.f), -1.f * cosf(plc.getRotation() * pi / 180.f));
//	else if (!rtStop) dispPLC.move(-1.f * sinf(plc.getRotation() * pi / 180.f), 1.f * cosf(plc.getRotation() * pi / 180.f));
//}
