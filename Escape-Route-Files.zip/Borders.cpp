#include "Borders.h"

unordered_map<Vector2f, vector<Vector2f>, Vector2fHash> Borders::borderGraph;

//void saveGraph(const string& filename, unordered_map<Vector2f, vector<Vector2f>, Vector2fHash>& borderGraph)
//{
//	ofstream outFile(filename);
//	if (!outFile.is_open()) {
//		cerr << "Error: Could not open file to save graph cache: " << filename << endl;
//		return;
//	}
//
//	cout << "Saving road graph to cache file: " << filename << "..." << endl;
//
//	// The file format will be:
//	// NodeX NodeY : Neighbor1X Neighbor1Y Neighbor2X Neighbor2Y ...
//	for (const auto& [node, neighbors] : borderGraph) {
//		outFile << node.x << " " << node.y << " :";
//		for (const auto& neighbor : neighbors) {
//			outFile << " " << neighbor.x << " " << neighbor.y;
//		}
//		outFile << "\n";
//	}
//
//	outFile.close();
//	cout << "Graph saved successfully." << endl;
//}
//
//void buildgraph(double RENDER_WORLD_SCALE_X, double RENDER_WORLD_SCALE_Y, unordered_map<Vector2f, vector<Vector2f>, Vector2fHash>& borderGraph, vector<Vector2f>& borderArea) {
//	cout << "Starting complex graph build..." << endl;
//	const int searchRadius = 1; // Connects nearby pixels of the same color.
//	unordered_set<Vector2f, Vector2fHash> cnt;
//	vector<Vector2f> dir = { {1,0},{0,1},{-1,0},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1} };
//	for (const auto& coord : borderArea) cnt.insert(coord);
//	for (const auto& coord : borderArea) {
//		for (int i = 0;i < dir.size();++i) {
//			bool connected = false;
//			float dx = dir[i].x;
//			float dy = dir[i].y;
//			Vector2f neighbor = coord + Vector2f(dx, dy);
//			if (cnt.count(neighbor)) {
//				borderGraph[coord].push_back(neighbor);
//			}
//
//		}
//	}
//	cout << "Graph build finished." << endl;
//	string name = "BorderGraph.cache";
//	saveGraph(name, borderGraph);
//}

void loadGraph(const string& filename, unordered_map<Vector2f, vector<Vector2f>, Vector2fHash>& borderGraph)
{
	ifstream inFile(filename);

	cout << "Loading road graph from cache file: " << filename << "..." << endl;
	borderGraph.clear(); // Ensure we start with a fresh graph

	string line;
	while (getline(inFile, line)) {
		if (line.empty()) continue;
		stringstream ss(line);
		Vector2f sourceNode;
		char colon;
		ss >> sourceNode.x >> sourceNode.y >> colon;

		vector<Vector2f> neighbors;
		Vector2f neighborNode;
		while (ss >> neighborNode.x >> neighborNode.y) {
			neighbors.push_back(neighborNode);
		}
		borderGraph[sourceNode] = neighbors;
	}
	inFile.close();
	cout << "Graph loaded successfully from cache." << endl;
}

Borders::Borders() : borderGrid(29335.f, 16504.f, 256, 256)
{
	float x, y;
	ifstream brd("BorderData.txt"); while (brd >> x >> y) { 
		borderGrid.addPoint({ x, y}); 
	} brd.close();
	loadGraph("BorderGraph.cache", borderGraph);
}

CollisionInfo Borders::checkBorders(Sprite& car, const Vector2f& carVelocity) {
    CollisionInfo info;
    const double pi = 3.14159265358979323846;
    vector<Vector2f> nearbyPoints = borderGrid.getNearbyPoints(car.getPosition());
    
    FloatRect bounds = car.getLocalBounds();

    // Get the sprite's final transform matrix
    const Transform& transform = car.getTransform();

    // Define the four corners in the sprite's own local coordinate system
    // (before any rotation, scaling, or positioning has been applied)
    vector<Vector2f> corners(4);
    corners[0] = Vector2f(bounds.left, bounds.top);                 // Top-left
    corners[1] = Vector2f(bounds.left + bounds.width, bounds.top);  // Top-right
    corners[2] = Vector2f(bounds.left + bounds.width, bounds.top + bounds.height); // Bottom-right
    corners[3] = Vector2f(bounds.left, bounds.top + bounds.height); // Bottom-left

    // Use the transform to convert each local corner point to its final world position
    corners[0] = transform.transformPoint(corners[0]);
    corners[1] = transform.transformPoint(corners[1]);
    corners[2] = transform.transformPoint(corners[2]);
    corners[3] = transform.transformPoint(corners[3]);

    Vector2f closestPoint,closestCorner;
    float min_dist_sq = -1.f;

    // First, find the single closest border point
    for (const auto& point : nearbyPoints) {
        for (const auto& p : corners) {
            float dx = p.x - (point.x * 29335.f / 1920.f);
            float dy = p.y - (point.y * 16504.f / 1080.f);
            float distSq = dx * dx + dy * dy;
            if (min_dist_sq < 0 || distSq < min_dist_sq) {
                min_dist_sq = distSq;
                closestPoint = point;
                closestCorner = p;
            }
        }
    }

    // If the closest point is within the car's radius, we have a collision.
    for (const auto& x : corners) {
        if (min_dist_sq > 0 && min_dist_sq < 10.f * 10.f) {
            info.collided = true;

            auto it = borderGraph.find(closestPoint);
            if (it != borderGraph.end()) {
                const vector<Vector2f>& neighbors = it->second;
                float best_dot = -2.f; // Start with a value lower than any possible dot product

                // The car's direction of impact
                Vector2f impactDir = normalize(-carVelocity);

                for (const auto& neighborMap : neighbors) {
                    Vector2f edgeDir = normalize(neighborMap - closestPoint);

                    // We want the edge that is most perpendicular to the impact direction.
                    float d = abs(dot(edgeDir, impactDir));
                    if (d > best_dot) {
                        best_dot = d;
                        info.wallDirection = edgeDir;
                    }
                }

                // The normal is perpendicular to the wall direction.
                info.railingNormal = { -info.wallDirection.y, info.wallDirection.x };
                // Ensure the normal points away from the wall towards the car
                if (dot(info.railingNormal, closestCorner - closestPoint) < 0) {
                    info.railingNormal *= -1.f;
                }
            }
            return info;
        }
    }
   

    return info;
}
