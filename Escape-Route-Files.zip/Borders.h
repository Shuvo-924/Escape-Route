#ifndef BORDERS_H
#define BORDERS_H
#include <SFML/Graphics.hpp>
#include <iostream>
#include "CustomFunctions.h"
#include "BorderGrid.h"
#include <unordered_set>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <istream>
#include <string>
#include <algorithm>

struct CollisionInfo {
	bool collided = false;
	Vector2f collisionPoint; // Where the collision happened
	Vector2f railingNormal;  // The direction the railing "pushes" back
	Vector2f wallDirection;
};

class Borders {
private:
	vector<Vector2f> borderArea; //Coordinates of Borders of the Road //Coordinates of Borders of the Road
	BorderGrid borderGrid;
public:
	Borders();
	CollisionInfo checkBorders(Sprite& car, const Vector2f& carVelocity);
	static unordered_map<Vector2f, vector<Vector2f>, Vector2fHash> borderGraph;
};

#endif
