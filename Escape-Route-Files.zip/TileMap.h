#ifndef TILEMAP_H
#define TILEMAP_H

#include <SFML/Graphics.hpp>
#include <string>
#include <vector>
#include <map>

using namespace sf;
using namespace std;

class TileMap : public Drawable {
public:
    TileMap(const string& tilesetPath, int tileSize, int mapWidthInTiles, int mapHeightInTiles);
    virtual void draw(RenderTarget& target, RenderStates states) const override;

private:
    int m_tileSize;
    int m_mapWidth;  
    int m_mapHeight;

    map<string, Texture> m_textures;
    vector<Sprite> m_sprites;
};

#endif